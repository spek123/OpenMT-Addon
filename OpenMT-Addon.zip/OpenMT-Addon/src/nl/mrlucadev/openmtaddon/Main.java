package nl.mrlucadev.openmtaddon;

import org.bukkit.plugin.java.JavaPlugin;

public class Main extends JavaPlugin {

    @Override
    public void onEnable() {
        System.out.println("[OpenMT-Addon] De plugin staat aan!");

    }

    @Override
    public void onDisable() {
        System.out.println("[OpenMT-Addon] De plugin staat uit!");

    }

}
